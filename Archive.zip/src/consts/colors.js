export default {
    red                 : '#d3292a',
    light_red           : '#f4c9c9',
    lightGray           :'#F7F7F7',
    midGray             :'#989898',
    gray                :'#414141',
    black               :'#000000',
    mstarda             :'#FFB909',
}