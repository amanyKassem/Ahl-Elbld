export default {
    url: 'https://ahlalbalad.aait-sa.com/backend/api/v1/',
};